<?php

require_once('../conexao.php');

if ($_SESSION['nivel'] != 1) {
  header('Location: ../index.php');
};


?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <?php include "title.php"; ?>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="shortcut icon" href="../assets/images/foodexpresslogo/logo.png" type="image/x-icon">
    <link rel="icon" href="../assets/images/foodexpresslogo/logo.png" type="image/x-icon">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- summernote -->
  <link rel="stylesheet" href="plugins/summernote/summernote-bs4.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>

<body class="hold-transition sidebar-mini">
  <div class="wrapper">
    <!-- Navbar -->
    <?php include "topbar.php"; ?>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <?php include "sidebar.php"; ?>
    <?php
    $edit = $_GET['edit'];

    $resultt = mysqli_query($conexao, "SELECT * FROM pedido where id=" . $edit . "");
    $roww = mysqli_fetch_array($resultt);


    if (isset($_POST['publise'])) {
        $situacaos = $_POST['situacao'];

        if($situacaos == 1){
            $situacao = 'Pendente';
        }else if($situacaos == 2){
            $situacao = 'Aprovado';
        }else if($situacaos == 3){
            $situacao = 'Concluido';
        }
   

        if ($edit != '') {
  
          $insertdata = mysqli_query($conexao, "UPDATE pedido SET situacao='$situacao' where id=" . $edit . "");
          echo "<script>alert('Atualizado com Sucesso');</script>
        <script>window.location.href = 'view_pedidos.php'</script>";
        }
      }

    ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1>Atualizar Pedido</h1>
            </div>
            <div class="col-sm-6">
              <a href="view_pedidos.php" class="btn btn-success"><i class="fa fa-eye" aria-hidden="true"></i> Visualizar Pedidos</a>
            </div>

          </div>
        </div><!-- /.container-fluid -->
      </section>

      <!-- Main content -->
      <section class="content">
        <div class="row">
          <div class="col-md-8">
            <form action="" method="post" enctype="multipart/form-data">
              <div class="card card-outline card-info">


                <div class="card-header">
                  <div class="form-group">
                    <label>Nome da Empresa</label>
                    <?php
                    $sql = 'SELECT * from fornecedor where id="'.$roww["idForne"].'"';
                            $query = mysqli_query($conexao,$sql);
                            $fornecedor = mysqli_fetch_array($query);
                        
                            echo "<h6>".$fornecedor['nome']."</h6>";
                    ?>
                  </div>
                </div>

                <div class="card-header">
                  <div class="form-group">
                    <label>Nome do Produto</label>
                    <?php echo '<h6>'.$roww['nomeProd'].'</h6>' ?>
                  </div>
                </div>

                <div class="card-header">
                  <div class="form-group">
                    <label>Quantidade</label>
                    <?php echo '<h6>'.$roww['quant'].'</h6>' ?>
                  </div>
                </div>

                <div class="card-header">
                  <div class="form-group">
                    <label>Peso</label>
                    <?php echo '<h6>'.$roww['peso'].'</h6>' ?>
                  </div>
                </div>

                <div class="card-header">
                  <div class="form-group">
                    <label>Local de Entrega</label>
                    <?php echo '<h6>'.$roww['localE'].'</h6>' ?>
                  </div>
                </div>

                <div class="card-header">
                  <div class="form-group">
                    <label>Situação:</label>
                    <select name="situacao" id="">
                    <option value="1">Pendente</option>
                    <option value="2">Aprovado</option>
                    <option value="3">Concluido</option>
                    </select>
                  </div>
                </div>

                <div class="card-header">
                  <div class="form-group">
                    <div class="row">
                      <div class="col-sm-6">
                        <!-- text input -->
                        <div class="form-group">
                          <button type="submit" name="publise" class="btn btn-block btn-warning btn-lg">Atualizar</button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </form>
          </div>
          <!-- /.col-->
        </div>
        <!-- ./row -->
      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <?php include "footer.php"; ?>

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
      <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
  </div>
  <!-- ./wrapper -->

  <!-- jQuery -->
  <script src="plugins/jquery/jquery.min.js"></script>
  <!-- Bootstrap 4 -->
  <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- AdminLTE App -->
  <script src="dist/js/adminlte.min.js"></script>
  <!-- AdminLTE for demo purposes -->
  <script src="dist/js/demo.js"></script>
  <!-- Summernote -->
  <script src="plugins/summernote/summernote-bs4.min.js"></script>
  <script>
    $(function() {
      // Summernote
      $('.textarea').summernote()
    })
  </script>
</body>

</html>