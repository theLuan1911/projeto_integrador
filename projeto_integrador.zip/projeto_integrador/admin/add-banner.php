<?php

require_once('../conexao.php');

if ($_SESSION['nivel'] != 1) {
  header('Location: ../index.php');
};

$a=5;
?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <?php include "title.php"; ?>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="shortcut icon" href="../assets/images/foodexpresslogo/logo.png" type="image/x-icon">
    <link rel="icon" href="../assets/images/foodexpresslogo/logo.png" type="image/x-icon">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- summernote -->
  <link rel="stylesheet" href="plugins/summernote/summernote-bs4.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>

<body class="hold-transition sidebar-mini">
  <div class="wrapper">
    <!-- Navbar -->
    <?php include "topbar.php"; ?>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <?php include "sidebar.php"; ?>
    <?php



    if (isset($_POST['publise'])) {

      $titulo = $_POST['titulo'];
      $subtitulo = $_POST['subtitulo'];
      $comentario = $_POST['comentario'];
      $ativo = $_POST['ativo'];
      $url = $_POST['url'];


      if ($ativos = 'sim') {
        $ativo = 1;
      } else if ($ativos = 'nao') {
        $ativo = 2;
      }
 

      if ($_FILES['lis_img']['name'] != '') {
        $lis_img = rand() . $_FILES['lis_img']['name'];
      } else {
        $lis_img = $roww["img"];
      }

      $tempname = $_FILES['lis_img']['tmp_name'];

      $folder = "images/main-slider/" . $lis_img;
      if ($edit == '') {

        move_uploaded_file($tempname, $folder);

        $insertdata = mysqli_query($conexao, "INSERT INTO banner(titulo,subtitulo,comentario,url,ativo)VALUES('$titulo','$subtitulo','$comentario','$lis_img','$ativo')");
        echo "<script>alert('Postado com Sucesso');</script>
        <script>window.location.href = 'view_banner.php'</script>";
      } else {
        move_uploaded_file($tempname, $folder);

        $insertdata = mysqli_query($conexao, "UPDATE banner SET titulo='$titulo',subtitulo='$subtitulo',comentario='$comentario',url='$lis_img',ativo='$ativo' where id=" . $edit . "");
        echo "<script>alert('Atualizado com Sucesso');</script>
        <script>window.location.href = 'view_banner.php'</script>";
      }
    }

    ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1>Adicionar Banner</h1>
            </div>
            <div class="col-sm-6">
              <a href="view_banner.php" class="btn btn-success"><i class="fa fa-eye" aria-hidden="true"></i> Visualizar Banner</a>
            </div>

          </div>
        </div><!-- /.container-fluid -->
      </section>

      <!-- Main content -->
      <section class="content">
        <div class="row">
          <div class="col-md-8">
            <form action="" method="post" enctype="multipart/form-data">
              <div class="card card-outline card-info">


                <div class="card-header">
                  <div class="form-group">
                    <label>Título</label>
                    <input name="titulo" type="text" class="form-control" placeholder="Título">
                  </div>
                </div>

                <div class="card-header">
                  <div class="form-group">
                    <label>Subtitulo</label>
                    <input name="subtitulo" type="text" class="form-control" placeholder="Subtítulo">
                  </div>
                </div>

                <div class="card-header">
                  <div class="form-group">
                    <label>Comentario</label>
                    <input name="comentario" type="text" class="form-control" placeholder="Comentario">
                  </div>
                </div>

                <div class="card-header">
                  <div class="form-group">
                    <label>Ativo</label>
                    <select name="ativo" id="">
                    <option value="1">Sim</option>
                    <option value="2">Não</option>
                    </select>
                  </div>
                </div>

                <!--    	
			<div class="card-body pad">
			<label>Full Description</label>
              <div class="mb-3">
                <textarea name="descrip" class="textarea" placeholder="Place some text here"
                          style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"><?php echo $roww["descrip"]; ?></textarea>
              </div>
            </div>-->
                <div class="card-header">
                  <div class="form-group">
                    <label for="exampleInputFile">Selecionar Imagem<span style="color:red;">(Somente nesse tamanho)</span></label>
                    <p style="color:red;">Tamanho Máximo 1800px x 820px</p>
                    <input name="lis_img" type="file" required>

                  </div>
                </div>

                <div class="card-header">
                  <div class="form-group">
                    <div class="row">
                      <div class="col-sm-6">
                        <!-- text input -->
                        <div class="form-group">
                          <button type="submit" name="publise" class="btn btn-block btn-warning btn-lg">Publicar</button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </form>
          </div>
          <!-- /.col-->
        </div>
        <!-- ./row -->
      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <?php include "footer.php"; ?>

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
      <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
  </div>
  <!-- ./wrapper -->

  <!-- jQuery -->
  <script src="plugins/jquery/jquery.min.js"></script>
  <!-- Bootstrap 4 -->
  <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- AdminLTE App -->
  <script src="dist/js/adminlte.min.js"></script>
  <!-- AdminLTE for demo purposes -->
  <script src="dist/js/demo.js"></script>
  <!-- Summernote -->
  <script src="plugins/summernote/summernote-bs4.min.js"></script>
  <script>
    $(function() {
      // Summernote
      $('.textarea').summernote()
    })
  </script>
</body>

</html>