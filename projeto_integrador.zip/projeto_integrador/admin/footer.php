 <footer class="main-footer">
    <strong>Copyright &copy; 2022 <a href=""></a>.</strong> Todos direitos reservados
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 1.0.0
    </div>
  </footer>